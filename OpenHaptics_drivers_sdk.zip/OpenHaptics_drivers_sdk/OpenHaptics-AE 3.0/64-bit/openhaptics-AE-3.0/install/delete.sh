#!/bin/sh
/sbin/ldconfig
rmdir --ignore-fail-on-non-empty /usr/share/3DTouch/