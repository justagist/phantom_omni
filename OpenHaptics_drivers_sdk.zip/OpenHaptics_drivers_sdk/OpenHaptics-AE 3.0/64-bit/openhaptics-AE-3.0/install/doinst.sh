#!/bin/sh
/sbin/ldconfig